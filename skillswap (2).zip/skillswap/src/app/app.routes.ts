import { Routes } from '@angular/router';

import { LoginComponent } from './components/login/login';
import { RegisterComponent } from './components/register/register';
import { JobsComponent } from './components/jobs/jobs';

export const routes: Routes = [

  { path: 'login', component: LoginComponent },

  { path: 'register', component: RegisterComponent },

  { path: 'jobs', component: JobsComponent },

  { path: '', component: LoginComponent }

];