import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { JobService } from '../../services/job.service';

@Component({
  selector: 'app-jobs',
  standalone: true,
  templateUrl: './jobs.html',
  styleUrls: ['./jobs.css']
})
export class JobsComponent {

  username = '';
  jobs: any[] = [];

  constructor(private router: Router, private jobService: JobService){

    // appel API pour récupérer les jobs
    this.jobService.getJobs().subscribe((data:any)=>{
      this.jobs = data.slice(0,6); // limite pour affichage
    });

  }

  logout(){
    this.router.navigate(['/login']);
  }

}