import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, RouterModule],
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class LoginComponent {

  email = '';
  password = '';
  error = '';

  constructor(private router: Router){}

  login(){

    fetch('https://jsonplaceholder.typicode.com/users')
      .then(res => res.json())
      .then(users => {

        const user = users.find((u:any) => u.email === this.email);

        if(user){
          this.router.navigate(['/jobs']);
        } else {
          this.error = "Invalid credentials";
        }

      })
      .catch(() => {
        this.error = "Error connecting to server";
      });

  }

}