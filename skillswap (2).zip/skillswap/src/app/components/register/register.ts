import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, RouterModule],
  templateUrl: './register.html',
  styleUrls: ['./register.css']
})
export class RegisterComponent {

  name = '';
  email = '';
  password = '';

  constructor(private router: Router){}

  register(){

    const user = {
      name: this.name,
      email: this.email,
      password: this.password
    };

    localStorage.setItem("username", this.name);
    this.router.navigate(['/login']);
  }

}