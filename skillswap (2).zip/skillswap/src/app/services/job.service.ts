import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class JobService {

  constructor(private http: HttpClient) {}

  getJobs(){
    return this.http.get('https://jsonplaceholder.typicode.com/posts');
  }

}